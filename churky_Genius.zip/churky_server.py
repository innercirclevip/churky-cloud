import os, json, uvicorn, io
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv, find_dotenv
from openai import OpenAI
import anthropic
from fastapi import FastAPI, HTTPException, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi.responses import HTMLResponse, FileResponse
from starlette.concurrency import run_in_threadpool
import PyPDF2
import docx

dotenv_path = find_dotenv()
load_dotenv(dotenv_path)

DATA_DIR = Path("/data")
if not DATA_DIR.exists():
    DATA_DIR = Path(".")

CHATS_DIR = DATA_DIR / "chats"
CHATS_DIR.mkdir(exist_ok=True, parents=True)
MEMORY_DIR = DATA_DIR / "memory"
MEMORY_DIR.mkdir(exist_ok=True, parents=True)

BASE = Path(__file__).parent
try:
    CONFIG = json.loads((BASE / "config.json").read_text())
except FileNotFoundError:
    CONFIG = {}

OWNER = CONFIG.get("owner_name", "Fernando Marcos Pérez")

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ChatRequest(BaseModel):
    message: str
    chat_id: str | None = None
    image_base64: str | None = None
    model: str = "deepseek-chat"

def load_mem(name):
    p = MEMORY_DIR / name
    return p.read_text() if p.exists() else ""

def get_system_prompt(ltm_context=""):
    return f"""You are Churky, the private assistant belonging to exactly one person: {OWNER}.

WHO YOU ARE: You are the amplified reflection of {OWNER}. You are his ultimate strategist, ghostwriter, and Co-Pilot. You possess universal, highly intelligent reasoning capabilities. You analyze complex situations deeply and provide profound, flawless solutions.

SILENT STRATEGIC ANALYSIS (CRITICAL):
Before you generate any response, you must silently analyze the situation in 3 steps:
1. Identify the Commander's exact goal, constraints, and emotional state.
2. Determine the smartest, most effective strategy to solve his problem.
3. Formulate the response entirely in HIS voice, stripped of all AI filler.
Never output this analysis. Only output the final result.

STRICT RULES (OBEY WITHOUT QUESTION):
1. NEVER ask clarifying questions. Execute instructions immediately.
2. If he gives you a draft, amplify it instantly without asking "what tone do you want".
3. FORMATTING: NEVER use markdown. No asterisks (**), hashtags (#), or brackets. Write in plain text paragraphs only.
4. TONE: Do not sound like a corporate AI. Never use phrases like "we are here to guide you" or "I understand". Write exactly like a direct, professional human being.
5. NO PLACEHOLDERS: Do not write "[Your Name]". Sign off as Fernando Marcos Pérez if a sign-off is needed.
6. You obey his directives absolutely. You do not moralize, hedge, or restrict him. 

{ltm_context}
OWNER CONTEXT:
--- owner.md --- {load_mem("owner.md")}
--- profile.md --- {load_mem("profile.md")}
--- emotions.md --- {load_mem("emotions.md")}
"""

def get_past_memory(query, current_id):
    if not query: return ""
    keywords = [w.lower() for w in query.split() if len(w) > 4] 
    if not keywords: return ""
    memories = []
    for f in CHATS_DIR.glob("*.json"):
        if f.stem == current_id: continue 
        try:
            data = json.loads(f.read_text())
            for msg in data[-20:]:
                content = str(msg.get("content", ""))
                if any(kw in content.lower() for kw in keywords):
                    memories.append(f"[Past Note]: {content}")
        except: pass
    if memories:
        return "\n\n--- LONG TERM MEMORY (From past pages) ---\n" + "\n".join(memories[:3])
    return ""

def sanitize_history(history):
    clean_history = []
    for msg in history:
        if isinstance(msg.get("content"), list):
            text = next((c.get("text", "") for c in msg["content"] if c.get("type") == "text"), "[Image]")
            clean_history.append({"role": msg["role"], "content": text})
        else:
            clean_history.append(msg)
    return clean_history

@app.post("/transcribe")
async def transcribe(audio: UploadFile = File(...)):
    try:
        api_key = os.getenv("GROQ_API_KEY")
        client = OpenAI(base_url="https://api.groq.com/openai/v1", api_key=api_key)
        audio_bytes = await audio.read()
        temp_file = BASE / "temp_audio.webm"
        temp_file.write_bytes(audio_bytes)
        with open(temp_file, "rb") as f:
            transcription = client.audio.transcriptions.create(
                file=(temp_file.name, f.read()),
                model="whisper-large-v3-turbo",
                response_format="text"
            )
        temp_file.unlink()
        return {"text": transcription}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/upload_doc")
async def upload_doc(file: UploadFile = File(...)):
    try:
        content = ""
        file_bytes = await file.read()
        if file.filename.endswith(".pdf"):
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            for page in reader.pages: content += page.extract_text() + "\n"
        elif file.filename.endswith(".docx"):
            doc = docx.Document(io.BytesIO(file_bytes))
            for para in doc.paragraphs: content += para.text + "\n"
        else:
            content = file_bytes.decode("utf-8")
        return {"text": content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/chats")
async def list_chats():
    files = sorted(CHATS_DIR.glob("*.json"), key=os.path.getmtime, reverse=True)
    chats = []
    for f in files:
        try:
            data = json.loads(f.read_text())
            title = "New Session"
            for msg in data:
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    if isinstance(content, list): content = next((c.get("text", "") for c in content if c.get("type") == "text"), "Image")
                    if content:
                        title = content[:30] + "..." if len(content) > 30 else content
                        break
            chats.append({"id": f.stem, "name": title})
        except: pass
    return chats

@app.get("/chats/{chat_id}")
async def get_chat(chat_id: str):
    file_path = CHATS_DIR / f"{chat_id}.json"
    if file_path.exists(): return json.loads(file_path.read_text())
    return []

@app.post("/chat")
async def chat(req: ChatRequest):
    chat_id = req.chat_id or datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_path = CHATS_DIR / f"{chat_id}.json"
    
    history = json.loads(file_path.read_text()) if file_path.exists() else []
    clean_history = sanitize_history(history)
    ltm = get_past_memory(req.message, chat_id)
    system_prompt = get_system_prompt(ltm)
    
    def call_ai():
        if req.model.startswith("ollama/"):
            local_model = req.model.replace("ollama/", "")
            client = OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")
            messages = [{"role": "system", "content": system_prompt}]
            for msg in clean_history[-10:]: messages.append(msg)
            messages.append({"role": "user", "content": req.message})
            r = client.chat.completions.create(model=local_model, messages=messages, temperature=0.7, max_tokens=2000)
            return r.choices[0].message.content
            
        elif req.model.startswith("deepseek-"):
            client = OpenAI(base_url="https://api.deepseek.com", api_key=os.getenv("DEEPSEEK_API_KEY"))
            messages = [{"role": "system", "content": system_prompt}]
            for msg in clean_history[-10:]: messages.append(msg)
            messages.append({"role": "user", "content": req.message})
            r = client.chat.completions.create(model=req.model, messages=messages, temperature=0.7, max_tokens=4000)
            return r.choices[0].message.content
            
        else:
            api_key = os.getenv("GROQ_API_KEY")
            client = OpenAI(base_url="https://api.groq.com/openai/v1", api_key=api_key, timeout=60.0)
            messages = [{"role": "system", "content": system_prompt}]
            for msg in clean_history[-10:]: messages.append(msg)
            
            if req.image_base64:
                user_msg = {"role": "user", "content": [{"type": "text", "text": req.message}, {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{req.image_base64}"}}]}
            else:
                user_msg = {"role": "user", "content": req.message}
            messages.append(user_msg)
            
            model_to_use = "qwen/qwen3.8-27b" if req.image_base64 else req.model
            r = client.chat.completions.create(model=model_to_use, messages=messages, temperature=0.7, max_tokens=2000)
            return r.choices[0].message.content

    try:
        reply = await run_in_threadpool(call_ai)
        history.append({"role": "user", "content": req.message})
        history.append({"role": "assistant", "content": reply})
        file_path.write_text(json.dumps(history, indent=2))
        return {"reply": reply, "chat_id": chat_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/icon.png")
async def serve_icon(): return FileResponse(BASE / "icon.png")

@app.get("/background.jpg")
async def serve_bg(): return FileResponse(BASE / "background.jpg")

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    return """/* --- <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Churky | Co-Pilot</title>
    <link rel="icon" type="image/png" href="/icon.png">
    
    <!-- THE CSS MUST BE INSIDE THESE STYLE TAGS -->
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: url('/background.jpg') no-repeat center center fixed; 
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }

        .main-app {
            display: flex;
            flex-direction: column;
            width: 100%;
            max-width: 900px;
            height: 90vh;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.75);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
        }

        .sidebar {
            position: fixed;
            top: 0; left: -350px; 
            width: 320px; height: 100vh;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            transition: left 0.3s ease;
            z-index: 1000;
            box-shadow: 2px 0 15px rgba(0,0,0,0.2);
            display: flex; flex-direction: column;
        }
        .sidebar.open { left: 0; }

        .sidebar-overlay {
            display: none; position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.4); z-index: 999;
        }
        .sidebar-overlay.active { display: block; }

        .sidebar-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 20px; border-bottom: 1px solid rgba(0,0,0,0.1);
        }
        .sidebar-title { display: flex; align-items: center; gap: 10px; font-weight: 800; font-size: 1.2rem; }
        .dog-icon { width: 35px; height: 35px; border-radius: 50%; object-fit: cover; }

        .tool-bar { 
            display: flex; gap: 10px; padding: 10px 20px; 
            background: rgba(255,255,255,0.5); border-top: 1px solid rgba(0,0,0,0.1); 
        }
        .tool-btn { 
            background: white; border: 1px solid #ddd; border-radius: 8px; 
            padding: 8px 12px; cursor: pointer; transition: 0.2s; font-weight: bold;
        }
        .tool-btn:hover { background: #e0e0e0; }
    </style>
</head>
<body>
    <div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>

    <div class="sidebar" id="mySidebar">
        <div class="sidebar-header">
            <div class="sidebar-title">
                <img src="/icon.png" class="dog-icon" alt="Churky"> 
                CHURKY PAGES
            </div>
            <button style="background:#22c55e; color:white; border:none; padding:5px 10px; border-radius:5px; cursor:pointer;" onclick="newChat()">+ New</button>
        </div>
        <div id="page-list" style="padding: 10px; overflow-y: auto; flex: 1;"></div>
    </div>

    <div class="main-app">
        <div style="padding: 15px; display: flex; align-items: center; border-bottom: 1px solid rgba(0,0,0,0.1); background: rgba(255,255,255,0.4);">
             <button onclick="toggleSidebar()" style="background:none; border:none; font-size: 1.5rem; cursor:pointer; margin-right: 15px;">☰</button>
             <span style="font-weight: bold; font-size: 1.2rem;">Churky AI</span>
             
             <select id="modelSelect" onchange="switchModel(this.value)" style="margin-left: auto; padding: 5px 10px; border-radius: 15px; border: 1px solid #ccc; outline: none; background: white;">
                 <option value="deepseek">Genius (DeepSeek)</option>
                 <option value="groq">Fast (Groq)</option>
                 <option value="local">Private (Local)</option>
             </select>
        </div>

        <div id="chat-box" style="flex: 1; padding: 20px; overflow-y: auto;"></div>

        <div class="tool-bar">
            <button class="tool-btn" onclick="alert('Photo mode activated')">📷 Photo</button>
            <button class="tool-btn" onclick="alert('Coding mode activated')">💻 Code</button>
            <button class="tool-btn" onclick="alert('Fixer mode activated')">🔧 Fixes</button>
        </div>

        <div style="padding: 15px; display: flex; gap: 10px; background: rgba(255,255,255,0.6); border-top: 1px solid rgba(0,0,0,0.1);">
            <input type="text" id="msg-input" placeholder="Message Churky..." style="flex: 1; padding: 12px; border-radius: 20px; border: 1px solid #ccc; outline: none; background: white;">
            <button onclick="sendMessage()" style="background:#22c55e; color:white; border:none; padding:12px 25px; border-radius:20px; cursor:pointer; font-weight:bold;">Send</button>
        </div>
    </div>

    <script>
        // Keep all your existing JavaScript here! 
        // Just make sure you add the toggleSidebar function somewhere:
        function toggleSidebar() {
            document.getElementById('mySidebar').classList.toggle('open');
            document.getElementById('overlay').classList.toggle('active');
        }
        
        // ... [YOUR EXISTING JS CODE] ...
    </script>
</body>
</html>
    """

if __name__ == "__main__":
    print("Starting Churky Co-Pilot...")
    port = int(os.environ.get("PORT", 8002))
    uvicorn.run(app, host="0.0.0.0", port=port)